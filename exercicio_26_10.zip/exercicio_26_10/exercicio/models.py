from django.db import models

# Create your models here.
from django.db import models

class Estado(models.Model):
    nome = models.CharField(max_length=100)
    sigla = models.CharField(max_length=2)

    def __str__(self):
        return self.nome

class Cidade(models.Model):
    nome = models.CharField(max_length=100)
    estado = models.ForeignKey(Estado, on_delete=models.CASCADE, related_name='cidades')

    def __str__(self):
        return self.nome

class Endereco(models.Model):
    rua = models.CharField(max_length=150)
    numero = models.CharField(max_length=10)
    bairro = models.CharField(max_length=100)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE, related_name='enderecos')

    def __str__(self):
        return f"{self.rua}, {self.numero}"

class Departamento(models.Model):
    nome = models.CharField(max_length=100)

    def __str__(self):
        return self.nome

class Funcionario(models.Model):
    nome = models.CharField(max_length=100)
    cpf = models.CharField(max_length=11)
    departamento = models.ForeignKey(Departamento, on_delete=models.SET_NULL, null=True, related_name='funcionarios')
    endereco = models.ForeignKey(Endereco, on_delete=models.SET_NULL, null=True, related_name='moradores')

    def __str__(self):
        return self.nome
