# Create your views here.
from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required

@login_required
def redirect_after_login(request):
    user = request.user
    if user.is_superuser:
        return redirect('pagina_admin')
    if hasattr(user, 'profile') and user.profile.role == 'gerente':
        return redirect('pagina_gerente')
    return redirect('pagina_usuario')

@login_required
def pagina_usuario(request):
    return render(request, 'usuario.html')

@login_required
def pagina_gerente(request):
    return render(request, 'gerente.html')

@login_required
def pagina_admin(request):
    return render(request, 'admin_page.html')
