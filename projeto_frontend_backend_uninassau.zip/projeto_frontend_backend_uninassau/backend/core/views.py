from django.shortcuts import render


# Páginas principais
def home(request):
    return render(request, "core/home.html")

def login(request):
    return render(request, "core/login.html")

def cadastro(request):
    return render(request, "core/cadastro.html")

def perfil(request):
    return render(request, "core/perfil.html")


# Páginas de autenticação extra
def alterar_senha(request):
    return render(request, "core/alterar_senha.html")

def recuperar_senha(request):
    return render(request, "core/recuperar_senha.html")

def logout(request):
    return render(request, "core/logout.html")


# Páginas de erro
# Erro 404 - Página não encontrada
def error_404(request, exception):
    return render(request, "core/404.html", status=404)

# Erro 403 - Acesso não permitido
def error_403(request, exception):
    return render(request, "core/403.html", status=403)

# Erro 500 - Erro do servidor
def error_500(request):
    return render(request, "core/500.html", status=500)
