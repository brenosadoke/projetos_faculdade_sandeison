from rest_framework import viewsets, permissions
from .models import Gasto
from .serializers import GastoSerializer

class GastoViewSet(viewsets.ModelViewSet):
    queryset = Gasto.objects.all()
    serializer_class = GastoSerializer
    permission_classes = [permissions.AllowAny]
