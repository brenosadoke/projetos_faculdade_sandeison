from django.urls import path
from . import views

urlpatterns = [
    # Páginas principais
    path('', views.home, name="home"),
    path('login/', views.login, name="login"),
    path('cadastro/', views.cadastro, name="cadastro"),
    path('perfil/', views.perfil, name="perfil"),

    # Autenticação extra
    path('alterar-senha/', views.alterar_senha, name="alterar_senha"),
    path('recuperar-senha/', views.recuperar_senha, name="recuperar_senha"),
    path('logout/', views.logout, name="logout"),

    # Páginas de erro (normalmente acessadas só quando o erro acontece)
    path('403/', views.error_403, name="erro_403"),
    path('404/', views.error_404, name="erro_404"),
    path('500/', views.error_500, name="erro_500"),

    path("pessoas/", views.listar_pessoas, name="listar_pessoas"),
]
