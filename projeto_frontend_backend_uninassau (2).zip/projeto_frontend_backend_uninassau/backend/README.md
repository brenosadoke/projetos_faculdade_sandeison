# Projeto Acadêmico - backend e frontend

Este projeto foi desenvolvido como parte das atividades da disciplina **[backend frontend]**, orientada pelo professor **[sandeison]**, no curso de **[ciencia da cmputaçao] - [uninassau]**.  

O repositório reúne as atividades propostas ao longo do semestre, , com foco em consolidar conhecimentos em desenvolvimento **fullstack** e boas práticas de programação.

---
---
---

## 📅 Organização
- Atividades divididas por **dias/pastas**  
- Cada atividade possui seu próprio **README** (quando aplicável)   
---


