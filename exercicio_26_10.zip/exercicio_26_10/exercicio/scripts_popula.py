from .models import Estado, Cidade, Departamento, Endereco, Funcionario

def run():
    estado, _ = Estado.objects.get_or_create(nome="São Paulo", sigla="SP")
    cidade, _ = Cidade.objects.get_or_create(nome="Campinas", estado=estado)
    departamento, _ = Departamento.objects.get_or_create(nome="TI")

    for i in range(1, 51):
        end, _ = Endereco.objects.get_or_create(
            rua=f"Rua {i}", numero=str(i), bairro="Centro", cidade=cidade
        )
        Funcionario.objects.get_or_create(
            nome=f"Funcionario {i}",
            cpf=f"{10000000000 + i}",
            departamento=departamento,
            endereco=end
        )

    print("População concluída.")
