from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User
from .models import Pessoa, Endereco

# Páginas principais
def home(request):
    return render(request, "core/home.html")

def login(request):
    if request.method == "POST":
        usuario = request.POST.get("username")
        senha = request.POST.get("password")
        print(f"Usuário: {usuario}, Senha: {senha}")  # Vai aparecer no terminal
        return HttpResponse("Login recebido! Veja o console.")
    return render(request, "core/login.html")

def cadastro(request):
    return render(request, "core/cadastro.html")

def perfil(request):
    return render(request, "core/perfil.html")

# Páginas de autenticação extra
def alterar_senha(request):
    return render(request, "core/alterar_senha.html")

def recuperar_senha(request):
    return render(request, "core/recuperar_senha.html")

def logout(request):
    return render(request, "core/logout.html")

# Páginas de erro
def error_404(request, exception):
    return render(request, "core/404.html", status=404)

def error_403(request, exception):
    return render(request, "core/403.html", status=403)

def error_500(request):
    return render(request, "core/500.html", status=500)

# Listar pessoas com usuários e endereços
from django.shortcuts import render
from django.contrib.auth.models import User
from .models import Pessoa, Endereco

def listar_pessoas(request):
    lista_pessoas = []

    pessoas = Pessoa.objects.all().values()
    for p in pessoas:
        usuario = User.objects.get(id=p['usuario_id'])
        endereco = Endereco.objects.filter(pessoa_id=p['id']).first()  

        lista_pessoas.append({
            'nome': p['nome'],
            'cpf': p['cpf'],
            'email': p['email'],
            'telefone': p['telefone'],
            'data_nascimento': p['data_nascimento'],
            'rg': p['rg'],
            'usuario_nome': usuario.username,
            'usuario_email': usuario.email,
            'endereco_rua': endereco.rua if endereco else "",
            'endereco_numero': endereco.numero if endereco else "",
            'bairro': endereco.bairro if endereco else ""
        })

    return render(request, "core/listar_pessoas.html", {"pessoas": lista_pessoas})

