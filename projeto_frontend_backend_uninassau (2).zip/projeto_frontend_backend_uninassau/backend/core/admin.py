from django.contrib import admin
from .models import Pessoa

@admin.register(Pessoa)
class PessoaAdmin(admin.ModelAdmin):
    list_display = ("nome", "cpf", "email", "telefone", "data_nascimento", "rg", "bairro")
    search_fields = ("nome", "cpf", "email", "rg")
# Register your models here.
