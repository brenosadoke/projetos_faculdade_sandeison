from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Estado, Cidade, Endereco, Departamento, Funcionario

@admin.register(Estado)
class EstadoAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome', 'sigla')
    search_fields = ('nome',)
    list_per_page = 25

@admin.register(Cidade)
class CidadeAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome', 'estado')
    search_fields = ('nome',)
    list_filter = ('estado',)
    list_select_related = ('estado',)
    list_per_page = 40

@admin.register(Endereco)
class EnderecoAdmin(admin.ModelAdmin):
    list_display = ('id', 'rua', 'numero', 'bairro', 'cidade')
    search_fields = ('rua', 'bairro', 'cidade__nome')
    list_filter = ('cidade__estado',)
    list_select_related = ('cidade',)
    raw_id_fields = ('cidade',)
    list_per_page = 25

@admin.register(Departamento)
class DepartamentoAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome')
    search_fields = ('nome',)
    list_per_page = 25

@admin.register(Funcionario)
class FuncionarioAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome', 'cpf', 'departamento', 'endereco')
    search_fields = ('nome', 'cpf', 'departamento__nome')
    list_filter = ('departamento',)
    list_select_related = ('departamento', 'endereco')
    raw_id_fields = ('departamento', 'endereco')
    list_per_page = 25
