from django.apps import AppConfig

class GastosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gastos'
