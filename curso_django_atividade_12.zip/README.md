# curso_django - Atividade 12

Projeto Django + Django REST Framework para atividade da faculdade.

## O que tem aqui
- app `users`: endpoints CRUD para usuários (usa User do Django)
- app `gastos`: model `Gasto` com campos `user`, `descricao`, `valor`, `data`
- ViewSets + Routers configurados em `curso_django/urls.py`
- Endpoints expostos em `/api/users/` e `/api/gastos/`

## Como rodar (resumo)
1. Crie um virtualenv e ative:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # venv\Scripts\activate on Windows
   ```
2. Instale dependências:
   ```bash
   pip install -r requirements.txt
   ```
3. Migre o banco:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```
4. Crie superuser (opcional):
   ```bash
   python manage.py createsuperuser
   ```
5. Rode o servidor:
   ```bash
   python manage.py runserver
   ```
6. Teste endpoints:
   - `GET/POST`  `http://127.0.0.1:8000/api/users/`
   - `GET/POST`  `http://127.0.0.1:8000/api/gastos/`

## Observações importantes
- Configuração de produção (SECRET_KEY, DEBUG=False, ALLOWED_HOSTS) NÃO estão prontos.
- Para facilitar correção: permissões estão definidas como `AllowAny`. Se quiser restringir criação/edição de gastos para usuários autenticados, altere `permission_classes`.

